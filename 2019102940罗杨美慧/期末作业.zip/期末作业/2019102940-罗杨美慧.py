import random

islogin = False

#定义产生验证码函数
def generate_checkcode(n):

    s = '1234567890zxcvbnmasdfghjklqwertyuiopZXCVBNMASDFGHJKLQWERTYUIOP'
    code = ''
    for i in range(n):
        ran = random.randint(0,len(s)-1)
        code += s[ran]

    return code


#定义登录函数
def login():

    username = input('请输入用户名：')
    password = input('请输入密码：')
    # 得到一个验证码
    code = generate_checkcode(5)  # 函数调用
    print('验证码是：', code)
    code1 = input('请输入验证码：')

    if code1.lower() == code.lower():
        if username == 'lymh' and password == '970820':
            return True
        else:
            return False
    else:
        return False


#登录游戏验证装饰器
def login_required(func):

    def wrapper(*args,**kwargs):
        global islogin
        print('----------进入游戏----------')
        if islogin:
            func(*args,**kwargs)
        else:
            print('用户没登录不能进入游戏')
            islogin = login()
            if islogin == True:
                print('登陆成功，欢迎进入游戏！')
                play()    #调用函数
            else:
                print('登陆失败！')

    return wrapper


#进入游戏函数
@login_required
def play():

    print('*' * 32)
    print('\t欢迎来到王者荣耀')
    print('*' * 32)

    role = input('请选择游戏人物（输入人物名字）：（1.鲁班 2.后羿 3.李白 4.孙尚香 5.貂蝉 6.诸葛亮 7.孙悟空 8.吕布）')
    coins = 800
    weapon_list = []
    print('欢迎{}来到王者峡谷，当前金币是：{}'.format(role, coins))

    while True:
        choice = int(input('\n请选择（输入序号）：\n 1.购买装备\n 2.打仗\n 3.删除装备\n 4.查看装备\n 5.退出游戏\n'))

        if choice == 1:
            # 购买装备
            print('欢迎来到装备库，有以下装备可以选择购买：')
            weapons = [['反伤刺甲', 1840], ['红莲斗篷', 1830], ['无尽战刃', 2140], ['冰霜法杖', 2100], ['回响之杖', 2100],
                       ['贤者之书', 2990],['疾步之靴', 590],['极速战靴', 710],['近卫荣耀', 2010],['泣血之刃', 1740]]
            for weapon in weapons:
                print(weapon[0], weapon[1], sep='    ')

            weaponname = input('请输入要购买的装备名称：')
            if weaponname not in weapon_list:
                for weapon in weapons:
                    if weaponname == weapon[0]:
                        if coins > weapon[1]:
                            coins -= weapon[1]
                            weapon_list.append(weapon[0])
                            print('{}购买装备：{}成功！'.format(role, weaponname))
                            break
                        else:
                            print('金币不足，赶快打仗赚金币吧')
                            break
                else:
                    print('输入装备名称错误！')

        elif choice == 2:
            # 打仗（默认与张飞比大小）
            print('....进入战场....')
            if len(weapon_list) > 0:
                print('{}拥有的装备如下：'.format(role))
                for weapon in weapon_list:
                    print(weapon)

                while True:
                    weaponname = input('请选择：')
                    if weaponname in weapon_list:
                        ran1 = random.randint(1, 20)
                        ran2 = random.randint(1, 20)
                        if ran1 > ran2:
                            print('此局对战：张飞胜！！！你输了！！！')
                        elif ran1 < ran2:
                            coins += 2000
                            print('此局对战：{}胜！金币剩余：{}'.format(role, coins))
                        else:
                            print('此局对战平局！')
                        break
                    else:
                        print('选择的装备不存在，请重新选择')
            else:
                print('你没有装备，请购买！')

        elif choice == 3:
            # 删除装备
            print('装备太多，扔几个吧...')
            if len(weapon_list) > 0:
                print('{}拥有的装备如下：'.format(role))
                for weapon in weapon_list:
                    print(weapon)

                while True:
                    weaponname = input('请选择要删除的装备的名称：')
                    if weaponname in weapon_list:
                        weapon_list.remove(weaponname)
                        print('删除成功！')
                        for weapon in weapons:
                            if weaponname == weapon[0]:
                                coins += weapon[1]
                                break
                        break
                    else:
                        print('装备输入有误！')
            else:
                print('你都没有装备。。赶快购买去吧！')

        elif choice == 4:
            # 查看武器
            print('{}拥有的装备如下：'.format(role))
            for weapon in weapon_list:
                print(weapon)
            print('总金币：', coins)

        elif choice == 5:
            answer = input('确定要离开游戏吗？（是 or 否）')
            if answer == '是':
                print('game over!')
                break
        else:
            print('输入错误，请重新选择')


if __name__ == '__main__':
    play()