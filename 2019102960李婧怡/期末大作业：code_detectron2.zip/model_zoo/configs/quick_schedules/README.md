These are quick configs for performance or accuracy regression tracking purposes.
