import urllib.request
import os
import tarfile
import pickle
from PIL import Image
os.environ['TF_CPP_MIN_LOG_LEVEL'] = "3"

#下载数据
url="http://www.cs.toronto.edu/~kriz/cifar-10-python.tar.gz"
filepath='data/cifar-10-python.tar.gz'
if not os.path.isfile(filepath):
    result=urllib.request.urlretrieve(url,filepath)
    print("downloaded:",result)
else:
    print("data file already exists.")

#解压
if not os.path.exists("data/cifar-10-batches-py"):
    tfile=tarfile.open("data/cifar-10-python.tar.gz",'r:gz')
    result=tfile.extractall("data/")
    print('Extracted to ./data/cifar-10-batches-py/')
else:
    print("Directory already exists.")

#存取参数
parameters_path='data/parameters.txt'

import os
import numpy as np
import pickle as p
import tensorflow as tf

#加载批次数据
def load_CIFAR_batch(filename):
    """load single batch of cifar"""
    with open(filename,'rb') as f:
        #一个样本由标签和图像数据组成
        #<1xlabel><3072xpixel>(3072=32*32*3)
        #...
        #<1xlabel><3072xpixel>
        data_dict=p.load(f,encoding='bytes')
        images=data_dict[b'data']
        labels=data_dict[b'labels']

        #把原始数据结构调整为：BCWH
        images=images.reshape(10000,3,32,32)
        #tensorflow处理图像数据的结构：BWHC
        #把通道数据C移动到最后一个维度
        images=images.transpose(0,2,3,1)
        labels=np.array(labels)
        return images,labels

#加载数据
def load_CIFAR_data(data_dir):
    images_train = []
    labels_train = []
    for i in range(5):
        f = os.path.join(data_dir, 'data_batch_%d' % (i + 1))
        print('loading ', f)
        # 调用load_CIFAR_batch()获得批量的图像及其对应的标签
        image_batch, label_batch = load_CIFAR_batch(f)
        images_train.append(image_batch)
        labels_train.append(label_batch)
        Xtrain = np.concatenate(images_train)
        Ytrain = np.concatenate(labels_train)
        del image_batch, label_batch

    Xtest, Ytest = load_CIFAR_batch(os.path.join(data_dir, 'test_batch'))
    print('finish loadding CIFAR-10 data')

    # 返回训练集的图像和标签，测试集的图像和标签
    return Xtrain, Ytrain, Xtest, Ytest


data_dir = 'data/cifar-10-batches-py'
Xtrain, Ytrain, Xtest, Ytest = load_CIFAR_data(data_dir)
#显示数据集信息
print("------数据信息显示-------")
print('training data shape:',Xtrain.shape)
print('training labels shape:',Ytrain.shape)
print('test data shape:',Xtest.shape)
print('test labels shape:',Ytest.shape)

# 归一化
Xtrain_normalize = Xtrain.astype('float32')/255.0
Xtest_normalize = Xtest.astype('float32')/255.0
print(Xtrain_normalize[0][0][0])

from sklearn.preprocessing import OneHotEncoder

encoder = OneHotEncoder(sparse=False,categories='auto')

yy = [[0],[1],[2],[3],[4],[5],[6],[7],[8],[9]]
encoder.fit(yy)
# 转置
Ytrain_reshpe = Ytrain.reshape(-1,1)
Ytest_reshpe = Ytest.reshape(-1,1)
# 独热编码
Ytrain_onehot = encoder.transform(Ytrain_reshpe)
Ytest_onehot = encoder.transform(Ytest_reshpe)
# 定义权值
def weight(shape):
    return tf.Variable(tf.truncated_normal(shape,stddev=0.1),name='W')

# 定义偏置项
def bias(shape):
    return tf.Variable(tf.constant(0.1,shape=shape),name='b')

# 定义卷积操作
# 步长为1，paddding为'SAME'，即卷积后图片大小不变化
def conv2d(x,W):
    return tf.nn.conv2d(x,W,strides=[1,1,1,1],padding="SAME")

# 定义池化操作
# 步长为2，即原尺寸的长和宽除以2
def max_pool(x):
    return tf.nn.max_pool(x,ksize=[1,3,3,1],strides=[1,2,2,1],padding='SAME')
def avg_pool(x):
    return tf.nn.avg_pool(x,ksize=[1,3,3,1],strides=[1,2,2,1],padding='SAME')

# 输入层
# 32x32图像，通道为3(RGB)
# 用tf.name_scope('inputt_layer')将下面结构打包成input_layer
with tf.name_scope('inputt_layer'):
    x = tf.placeholder('float', shape=[None, 32, 32, 3], name='X')

# 第一个卷积层
# 输入通道：3，输出通道：32，卷积后图像尺寸不变，依然是32x32
with tf.name_scope('conv_1'):
    W1 = weight([5, 5, 3, 32])  # [k_wight,k_height,input_chn,output_chn]
    b1 = bias([32])  # 与output_chn一致
    conv_1 = tf.nn.relu(conv2d(x, W1) + b1)
x_input = tf.reshape(x, [-1, 32, 32, 3])
tf.summary.image('input', x_input, max_outputs=4)
img_conv1 = W1[:, :, :, 0:1]
tf.summary.image('conv1', img_conv1, max_outputs=4)

# 第一个池化层
# 将32x32的图像缩小为16x16，不改变通道数
with tf.name_scope('pool_1'):
    pool_1 = max_pool(conv_1)

# 第二个卷积层
# 输入通道：32，输出通道：32，卷积后图像尺寸不变，依然是32x32
with tf.name_scope('conv_2'):
    W2 = weight([5, 5, 32, 32])  # [k_wight,k_height,input_chn,output_chn]
    b2 = bias([32])  # 与output_chn一致
    conv_2 = tf.nn.relu(conv2d(pool_1, W2) + b2)

# 第二个池化层
# 将16x16的图像缩小为8x8，不改变通道数
with tf.name_scope('pool_2'):
    pool_2 = avg_pool(conv_2)

# 第三个卷积层
# 输入通道：32，输出通道：64，卷积后图像尺寸不变，依然是32x32
with tf.name_scope('conv_3'):
    W3 = weight([5, 5, 32, 64])  # [k_wight,k_height,input_chn,output_chn]
    b3 = bias([64])  # 与output_chn一致
    conv_3 = tf.nn.relu(conv2d(pool_2, W3) + b3)

# 第三个池化层
# 将8x8的图像缩小为4x4，不改变通道数
with tf.name_scope('pool_2'):
    pool_3 = avg_pool(conv_3)

# 全连接层
# 将64个4x4的图像转换为一维的向量，长度是64*4*4=1024
# 80个神经元
with tf.name_scope('fc'):
    W3 = weight([1024,80])
    b3 = bias([80])
    flat = tf.reshape(pool_3, [-1, 1024])  # 将pool_2展开为1行1024列的向量
    h = tf.nn.relu(tf.matmul(flat, W3) + b3)
    # 使用dropout方法使20%的神经元消失，防止神经网络过拟合
    # h_dropout = tf.nn.dropout(h, keep_prob=0.8)

# 输出层
# 输出层有10个神经元，对应10个类别
with tf.name_scope('output_layer'):
    W4 = weight([80, 10])
    b4 = bias([10])
    pred = tf.nn.softmax(tf.matmul(h, W4) + b4)
with tf.name_scope('optimizer'):
    # 定义占位符
    y = tf.placeholder('float',shape=[None,10],name='label')
    # 定义损失函数
    loss_fun = tf.reduce_mean(
        tf.nn.softmax_cross_entropy_with_logits
        (logits=pred,labels=y))
    # 选择优化器
    lr = 0.0001
    opt = tf.train.AdamOptimizer(lr).minimize(loss_fun)
with tf.name_scope('optimizer'):
    # 定义占位符
    y = tf.placeholder('float',shape=[None,10],name='label')
    # 定义损失函数
    loss_fun = tf.reduce_mean(
        tf.nn.softmax_cross_entropy_with_logits
        (logits=pred,labels=y))
    # 选择优化器
    lr = 0.0001
    opt = tf.train.AdamOptimizer(lr).minimize(loss_fun)
with tf.name_scope('evaluation'):
    # tf.argmax(x,1)返回x中每一行最大值的位置
    correct_prediction = tf.equal(tf.argmax(pred,1),tf.argmax(y,1))
    accuracy = tf.reduce_mean(tf.cast(correct_prediction,'float'))
def next_epoch(num, batch_size):
    index = np.random.randint(0,num-1,batch_size)
    batch_x = Xtrain_normalize[index]
    batch_y = Ytrain_onehot[index]
    return batch_x,batch_y
def next_epoch1(num, batch_size):
    index = np.random.randint(0,num-1,batch_size)
    batch_x = Xtest_normalize[index]
    batch_y = Ytest_onehot[index]
    return batch_x,batch_y
train_epochs = 50
batch_size = 50
total_batch = int(len(Xtrain) / batch_size)
display_step = 1
epoch_list = []
accuracy_list = []
loss_list = []
test_acc_list=[]
test_loss_list=[]
# epoch = tf.Variable(0,name='epoch',trainable=False)
#saver = tf.train.Saver()
init = tf.global_variables_initializer() #初始化
#开启会话
print("-------start--------")
with tf.Session() as sess:
    sess.run(init)
    writer = tf.summary.FileWriter(r'.\cifar-10\logs', sess.graph)
    merged = tf.summary.merge_all()
    for epoch in range(train_epochs):
        for i in range(total_batch):
            batch_x, batch_y = next_epoch(50000, batch_size)
            sess.run(opt, feed_dict={x: batch_x, y: batch_y})
        summary,loss, acc = sess.run([merged,loss_fun, accuracy], feed_dict={x: batch_x, y: batch_y})
        writer.add_summary(summary,epoch)
        if epoch % display_step == 0:
            print("Train Epoch:%02d" % (epoch + 1), "Loss=%f" % loss, "Accuracy=%.4f" % acc)
        epoch_list.append(epoch + 1)
        loss_list.append(loss)
        accuracy_list.append(acc)
        file = open(parameters_path, 'w')
        for v in tf.trainable_variables():
            file.write("全部参数"+"\n")
            file.write(str(v.eval()))
        file.close()

        #计算测试集上的准确率
        accuary_sum = 0
        sample_sum = 0
        test_acc_sum = 0
        test_loss_sum = 0
        test_total_batch = int(len(Xtest_normalize) / batch_size)
        for i in range(test_total_batch):
            test_image_batch = Xtest_normalize[i * batch_size:(i + 1) * batch_size]
            test_label_batch = Ytest_onehot[i * batch_size:(i + 1) * batch_size]
        test_batch_loss,test_batch_acc = sess.run([loss_fun,accuracy], feed_dict={x: test_image_batch, y: test_label_batch})
        test_acc_list.append(test_batch_acc)
        test_loss_list.append(test_batch_loss)
    batch_x, batch_y = next_epoch1(10000, batch_size)
    prediction_result = sess.run(tf.argmax(pred, 1), feed_dict={x: batch_x})
    label = sess.run(tf.argmax(batch_y, 1))

#计算每个的分类错误
def error_mean(prediction_result, label):
    m = len(label)
    print(m)
    num0 = 0
    error0 = 0
    num1 = 0
    error1 = 0
    num2 = 0
    error2 = 0
    num3 = 0
    error3 = 0
    num4 = 0
    error4 = 0
    num5 = 0
    error5 = 0
    num6 = 0
    error6 = 0
    num7 = 0
    error7 = 0
    num8 = 0
    error8 = 0
    num9 = 0
    error9 = 0
    for i in range(m):
        if label[i] == 0:
            num0 = num0 + 1
            if prediction_result[i] != 0:
                error0 = error0 + 1
        elif label[i] == 1:
            num1 = num1 + 1
            if prediction_result[i] != 1:
                error1 = error1 + 1
        elif label[i] == 2:
            num2 = num2 + 1
            if prediction_result[i] != 2:
                error2 = error2 + 1
        elif label[i] == 3:
            num3 = num3 + 1
            if prediction_result[i] != 3:
                error3 = error3 + 1
        elif label[i] == 4:
            num4 = num4 + 1
            if prediction_result[i] != 4:
                error4 = error4 + 1
        elif label[i] == 5:
            num5 = num5 + 1
            if prediction_result[i] != 5:
                error5 = error5 + 1
        elif label[i] == 6:
            num6 = num6 + 1
            if prediction_result[i] != 6:
                error6 = error6 + 1
        elif label[i] == 7:
            num7 = num7 + 1
            if prediction_result[i] != 7:
                error7 = error7 + 1
        elif label[i] == 8:
            num8 = num8 + 1
            if prediction_result[i] != 8:
                error8 = error8 + 1
        elif label[i] == 9:
            num9 = num9 + 1
            if prediction_result[i] != 9:
                error9 = error9 + 1

    error0_rate = error0 / num0
    error1_rate = error1 / num1
    error2_rate = error2 / num2
    error3_rate = error3 / num3
    error4_rate = error4 / num4
    error5_rate = error5 / num5
    error6_rate = error6 / num6
    error7_rate = error7 / num7
    error8_rate = error8 / num8
    error9_rate = error9 / num9
    print("airplane分类错误率", error0_rate)
    print("automobile分类错误率", error1_rate)
    print("bird分类错误率", error2_rate)
    print("cat分类错误率", error3_rate)
    print("deer分类错误率", error4_rate)
    print("dog分类错误率", error5_rate)
    print("frog分类错误率", error6_rate)
    print("horse分类错误率", error7_rate)
    print("ship分类错误率", error8_rate)
    print("trunk分类错误率", error9_rate)
error_mean(prediction_result, label)
import matplotlib.pyplot as plt

# 可视化训练集损失曲线
fig = plt.gcf()
fig.set_size_inches(4,2)
plt.plot(loss_list,label='loss')
plt.ylabel('loss')
plt.xlabel('epoch')
plt.title('Loss')
plt.legend(['loss'],loc='upper right')
plt.show()

#训练集正确率曲线
plt.plot(epoch_list,accuracy_list,label="accuracy")
fig=plt.gcf()
fig.set_size_inches(4,2)
plt.ylim(0.1,1)
plt.ylabel("accuracy")
plt.xlabel('epoch')
plt.legend()
plt.show()

#测试集损失值曲线
plt.plot(epoch_list,test_acc_list,label="accuracy")
fig=plt.gcf()
fig.set_size_inches(4,2)
plt.ylim(0.1,1)
plt.ylabel("test_accuracy")
plt.xlabel('epoch')
plt.legend()
plt.show()

#测试集正确率曲线
fig = plt.gcf()
fig.set_size_inches(4,2)
plt.plot(test_loss_list,label='loss')
plt.ylabel('loss')
plt.xlabel('epoch')
plt.title('Loss')
plt.legend(['loss'],loc='upper right')
plt.show()