import requests
from lxml import etree
import pandas as pd
import os

def get_html(url):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, '
                      'like Gecko) Chrome/69.0.3497.100 Safari/537.36'
    }

    try:
        html=requests.get(url,headers=headers)
        #设置编码方式
        html.encoding=html.apparent_encoding
        if html.status_code==200:
            print("成功获取源代码")
            #打印源代码
            # print(html.text)
        #否则的话把异常输出
    except Exception as e:
        print("获取源代码失败: %s" %e)

    #把源代码返回
    return html.text

#解析源代码的函数
def parse_html(html):
    html=etree.HTML(html)
    #每页有25个电影
    lis=html.xpath("//ol[@class='grid_view']/li")
    movies = []   #保存电影信息
    images=[]   #保存电影海报
    # print(len(lis))

    #对列表lis进行遍历
    for li in lis:
        #获取电影的名称
        name=li.xpath(".//a/span[@class='title']/text()")[0]
        #获取导演，主演
        #.strip()去掉空格
        director_actor=li.xpath(".//div[@class='bd']/p/text()")[0].strip()
        # 获取电影的信息
        info=li.xpath(".//div[@class='bd']/p/text()")[1].strip()
        #获取电影的评分
        rating_score=li.xpath(".//div[@class='star']/span[2]/text()")[0]
        #获取评分的人数
        number=li.xpath(".//div[@class='star']/span[4]/text()")[0]
        #获取电影的介绍
        introduce=li.xpath(".//p[@class='quote']/span/text()")[0]
        image=li.xpath(".//img/@src")[0]
        print(image)
        #把获取的数据保存成字典
        movie={"name":name,"director_actor":director_actor,"info":info,"rating_score":rating_score,"number":number,"introduce":introduce}
        #把movie存放在列表movie中
        # print(movie)
        movies.append(movie)
        images.append(image)

    return movies,images

def downloading(url,movie):

    #建立一个文件夹
    if "movieposter" in os.listdir(r'D:\pycharm_code'):
        pass
    else:
        os.mkdir('movieposter')
    os.chdir(r'D:\pycharm_code\movieposter')
    #获取电影海报
    img=requests.get(url).content
    with open(movie["name"]+".jpg","wb") as f:
        print("正则下载： %s:" %url)
        f.write(img)



if __name__=="__main__":
    url="https://movie.douban.com/top250"
    #获取网页源码
    html=get_html(url)
    #获取源代码之后开始解析
    movies=parse_html(html)[0]
    images = parse_html(html)[1]
    #把电影打印出来
    # for m in movies:
    #     print(m)

    #遍历图片
    for i in range(25):
        downloading(images[i],movies[i])

    os.chdir(r"D:\pycharm_code")
    #把抓捕的数据转换成DataFrame格式
    moviedata=pd.DataFrame(movies)
    # print(moviedata)
    # 把抓捕的数据保存到本地
    moviedata.to_csv('movie.csv',encoding='utf_8_sig')
    print("电影信息已经保存到本地")

