import pandas as pd
import jieba
# jieba用于分词
import numpy
from collections import defaultdict
import operator
import jieba.analyse

def get_data():
    # 读取数据
    data = pd.read_csv("movie.csv", encoding='utf-8')
    # 读取其中的一列，用来提取关键词
    introduce = data.loc[:, "introduce"]
    # 去掉为空的数据
    data = data.dropna()
    # 把数据转换成列表形式
    introduce = introduce.values.tolist()
    return introduce

def Separete_word(introduce):
    introduce_W = []
    # line相当于新闻的一条主题，并对 line进行分词
    for line in introduce:
        #     jieba.lcut(line)可以把当前的line进行分词
        current_segment = jieba.lcut(line)
        if len(current_segment) > 1 and current_segment != "\r\n":  # 换行符
            introduce_W.append(current_segment)
    return introduce_W

def read_stopwords():
    stopwords = pd.read_csv("stopword.txt", index_col=False, sep="\t", quoting=3, names=["stopword"], encoding="utf-8")
    return stopwords

def drop_stopwords(introduce,stopwords):
    introduce_W=[]
    for line in introduce:
        for i in line:
            for j in i:
                introduce_W.append(j)
                # print(j)

    introduce_clean = []
    all_words = []

    for word in introduce_W:
        line_clean = []
        if word in stopwords :  # 把出现在stopword.txt中的停用词去掉
            continue
        elif word==" ":
            continue
        line_clean.append(word)  # 去掉停用词的词
        all_words.append(str(word))  # 把所有的词进行统计
        introduce_clean.append(line_clean)

    return introduce_clean, all_words

def sort_word(introduce_clean):
    words_count = defaultdict(int)
    for row in introduce_clean:
        for i in row:
            words_count[i] += 1
    S_word = sorted(words_count.items(), key=operator.itemgetter(1), reverse=True)  # 根据词频降序排序
    return S_word


if __name__=="__main__":
    #获取数据
    introduce=get_data()
    #使用jieba进行分词
    introduce_W=Separete_word(introduce)
    introduce_W=pd.DataFrame({"content_S": introduce_W})
    #去掉数据的停用词
    stopwords=read_stopwords()
    #print(stopwords.head(20))

    introduce_W = introduce_W.values.tolist()
    # print(introduce_W)
    stopwords = stopwords.stopword.values.tolist()
    introduce_clean, all_words = drop_stopwords(introduce_W, stopwords)
    # print(type(introduce_clean))
    # print(introduce_clean)
    # print(type(all_words))
    # print(all_words)
    #进行词频统计并排序
    S_word=sort_word(introduce_clean)
    # print(S_word)



