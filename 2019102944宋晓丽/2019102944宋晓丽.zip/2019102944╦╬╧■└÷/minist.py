import tensorflow as tf
from PIL import Image
from matplotlib import pyplot as plt
import numpy as np
import os

#设置训练集、标记文件的路径和横向x、纵向y的保存路径
train_path = './digit/data/train_data/'
train_txt = './digit/data/train_data/train_label.txt'
x_train_savepath = './digit/minist_x_train.npy'
y_train_savepath = './digit/minist_y_train.npy'

#设置测试集、标记文件的路径和横向x、纵向y的保存路径
test_path = './digit/data/test_data/'
test_txt = './digit/data/test_data/test_label.txt'
x_test_savepath = './digit/minist_x_test.npy'
y_test_savepath = './digit/minist_y_test.npy'

#设置多分类参数的保存路径
patameters_savepath = './digit/multiclass_parameters.txt'

#将图片进行预处理,x存储图片预处理后的数据即输入特征，y存储相应的标签
'''
  spilit()以空格为中介实现图片路径和标签的分割
   np.array()将图片存储为单一数据类型的多维数组
   append()将括号里的元素添加到列表
   astype()实现类型转换
'''
def generateds(path, txt):
  f = open(txt, 'r')  
  lines = f.readlines()  
  f.close()  
  x, y = [], [] 
  for line in lines:  
      content = line.split() 
      img_path = path + content[0]  
      img = Image.open(img_path)
      img = np.array(img.convert('L'))  
      img = img / 255.  
      x.append(img)  
      y.append(content[1])  
  x = np.array(x) 
  y = np.array(y)
  y = y.astype(np.int64)  
  return x, y

#1.准备好数据集x_train,y_train,x_test,y_test，并将数据集进行分批次处理
'''
如果文件都存在并且能被找到，可以直接载入数据集
如果文件不是全部存在，先使用genareteds函数进行预处理，再生成数据集
os.path.exists()用来判断括号里的文件是否存在
np.load()实现数据读取
np.reshape()在不改变数据内容的情况下，改变一个数组的格式，参数及返回值
np.save()实现数据的保存
tf.cast()实现数据类型的转换
from_tensor_slices()实现使输入特征和标签值一一对应
batch()实现将数据集分批
'''
if os.path.exists(x_train_savepath) and os.path.exists(y_train_savepath) and os.path.exists(x_test_savepath) and os.path.exists(y_test_savepath):
    x_train_save = np.load(x_train_savepath)
    x_train = np.reshape(x_train_save, (len(x_train_save),784))
    y_train = np.load(y_train_savepath)
    x_test_save = np.load(x_test_savepath)
    x_test = np.reshape(x_test_save, (len(x_test_save), 784))
    y_test = np.load(y_test_savepath)
else:
    x_train, y_train = generateds(train_path, train_txt)
    x_test, y_test = generateds(test_path, test_txt)
    x_train_save = np.reshape(x_train, (len(x_train), -1))
    x_test_save = np.reshape(x_test, (len(x_test), -1))
    np.save(x_train_savepath, x_train_save)
    np.save(y_train_savepath, y_train)
    np.save(x_test_savepath, x_test_save)
    np.save(y_test_savepath, y_test)
    x_train = np.reshape(x_train_save, (len(x_train_save),784))
    x_test = np.reshape(x_test_save, (len(x_test_save),784))
x_train = tf.cast(x_train, tf.float32)
x_test = tf.cast(x_test, tf.float32)
train_bh = tf.data.Dataset.from_tensor_slices((x_train, y_train)).batch(128)
test_bh = tf.data.Dataset.from_tensor_slices((x_test, y_test)).batch(128)

#2.进行训练和测试
'''
tf.Variable()用来标记参数可训练
tf.random.truncated_normal()用来截断正分布
w1,b1是生成的神经网络参数，因为784个输入特征，所以输入层为784个输入节点；因为5分类，所以输出层为5个神经元
'''
w1 = tf.Variable(tf.random.truncated_normal([784, 5], stddev=0.1))
b1 = tf.Variable(tf.random.truncated_normal([5], stddev=0.1))
train_loss = []  
test_acc = []  
test_err = []  
test_arr=[]
for i in range(6):
  test_arr.append([])

# 训练部分
'''
学习率为0.15，正则化因子为0.01
每个epoch循环一次数据集，每个step循环一个batch，循环20轮，每轮99步
enumerate() 函数用于将一个可遍历的数据对象(如列表、元组或字符串)组合为一个索引序列，同时列出数据和数据下标
GradientTape()在eager模式下计算梯度
tf.matmul（）将矩阵a乘以矩阵b，生成a * b
softmax()用来激活函数
tf.one_hot()函数是将input转化为one-hot类型数据输出，相当于将多个数值联合放在一起作为多个相同类型的向量，可用于表示各自的概率分布，通常用于分类任务中作为最      后的FC层的输出，有时翻译成“独热”编码。
tf.reduce_mean()用于计算张量tensor沿着指定的数轴（tensor的某一维度）上的的平均值，主要用作降维或者计算tensor（图像）的平均值
tf.square()是对括号里的每一个元素求平方
tf.losses.categorical_crossentropy()是交叉熵函数
tape.gradient()是梯度带
assign_sub()通过从 "ref" 中减去 "value" 来更新 "ref"
通过神经网络乘加运算得到输出y,对y用softmax函数激活，通过均方误差损失函数得到loss_mse,通过交叉熵损失函数得到loss_ce，添加正则化项后得到loss,并计算loss对各个参数的  梯度，从而实现参数w1,b1的自更新 
'''
loss_all = 0  
for epoch in range(20): 
  for step, (x_train, y_train) in enumerate(train_bh):  
        with tf.GradientTape() as tape: 
            y = tf.matmul(x_train, w1) + b1  
            y = tf.nn.softmax(y)
            y_ = tf.one_hot(y_train, depth=5)
            loss_mse = tf.reduce_mean(tf.square(y_ - y))  
            loss_ce = tf.reduce_mean(tf.losses.categorical_crossentropy(y_, y))  
            loss = loss_ce + 0.01 * tf.nn.l2_loss(w1) 
            loss_all += loss.numpy() 
        grads = tape.gradient(loss, [w1, b1])
        w1.assign_sub(0.15 * grads[0])  
        b1.assign_sub(0.15 * grads[1])  
  print("Epoch {}, loss: {}".format(epoch, loss_all /99))
  train_loss.append(loss_all / 99) 
  loss_all = 0  

  #测试部分
  '''
  tf.multiply（）两个矩阵中对应元素各自相乘
  tf.argmax(input,axis)根据axis取值的不同返回每行或者每列最大值的索引
  tf.where()根据condition返回x或y中的元素
  tf.equal(x, y, name=None)判断，x, y 是不是相等，它的判断方法不是整体判断，而是逐个元素进行判断，如果相等就是True，不相等，就是False。
  tf.reduce_sum() 用于计算张量tensor沿着某一维度的和，可以在求和后降维
  使用前面训练后更新的参数进行预测，返回y中最大值的索引，即预测的分类，通过与标签做对比，错误的计入相应的错误分类
  '''
  total_correct, total_number = 0, 0
  err=[0,0,0,0,0,0]
  for x_test, y_test in test_bh:
      y = tf.matmul(x_test, w1) + b1
      y = tf.nn.softmax(y)
      pred = tf.argmax(y, axis=1)
      pred = tf.cast(pred, dtype=y_test.dtype)
      correct = tf.cast(tf.equal(pred, y_test), dtype=tf.int32)
      temp = tf.where(tf.equal(correct, 0), pred, -1)
      for i in range(temp.shape[0]):
          if temp[i] != -1:
             err[temp[i]]+=1
      correct = tf.reduce_sum(correct)
      total_correct += int(correct)
      total_number += x_test.shape[0]
  acc = total_correct / total_number
  test_acc.append(acc)
  err = (total_number - total_correct) / total_number
  test_err.append(err)
  for i in range(1,6):
      test.arr[i].append(err[i]/total_number)

#3.进行输出
# 存储多分类参数
'''
write() 方法用于向文件中写入指定字符串
numpy()用来转换成数组
'''
file = open(patameters_savepath, 'w')
for i in range(5):
    file.write(str(w1[i].numpy()) + '\n')
file.write(str(b1.numpy()) + '\n')
file.close()

#采用 matplotlib.pyplot绘制曲线
'''
plt.title()函数用于设置图像标题
plt.imshow()函数负责对图像进行处理,并显示其格式,但是不能显示
plt.colorbar()函数用于给子图添加颜色条
plt.show()用于显示图像
plt.xlabel()用于设置x轴的标签文本
plt.ylabel()用于设置y轴的标签文本
plt.plot(x,y) 用于打开x轴数据，y轴数据
plt.legend()函数主要的作用就是给图加上图例
plt.subplot()函数用于直接指定划分方式和位置进行绘图
'''

# 绘制频率计权曲线
for i in range(5):
    img = w1[:, i].numpy().reshape(28, 28)
    plt.title('multiclass parameter '+str(i+1))
    plt.imshow(img)
    plt.colorbar()
    plt.show()

# 绘制 loss 曲线
plt.title('loss curve') 
plt.xlabel('epoch') 
plt.ylabel('loss')  
plt.plot(train_loss, label="$loss$") 
plt.legend() 
plt.show() 


# 绘制 accuracy 曲线
plt.subplot(1, 2, 1)
plt.title('accuracy curve') 
plt.xlabel('epoch')  
plt.ylabel('acc')  
plt.plot(test_acc, label="$accuracy$")  
plt.show()

# 绘制 error 曲线
plt.subplot(1, 2, 2)
plt.title('error curve') 
plt.xlabel('epoch') 
plt.ylabel('err') 
plt.plot(test_err, label="$error$")  
plt.legend()
plt.show()


# 绘制error rate曲线
plt.title('error rate cruve')
for i in range(1,6):
  plt.plot(test_arr[i], label='the digit '+i+' error rate')
plt.legend()
plt.show()
