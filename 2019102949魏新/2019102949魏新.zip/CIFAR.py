import urllib.request
import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = "3"
import tarfile
from PIL import Image
import numpy as np
import pickle as p
import tensorflow as tf
from sklearn.preprocessing import OneHotEncoder
import matplotlib.pyplot as plt

def load_CIFAR_batch(filename):
    with open(filename,'rb') as f:
        data_dict=p.load(f,encoding='bytes')
        images=data_dict[b'data']
        labels=data_dict[b'labels']
        images=images.reshape(10000,3,32,32)
        images=images.transpose(0,2,3,1)
        labels=np.array(labels)
        return images,labels

def load_CIFAR_data(data_dir):
    images_train = []
    labels_train = []
    for i in range(5):
        f = os.path.join(data_dir, 'data_batch_%d' % (i + 1))
        print('loading ', f)
        image_batch, label_batch = load_CIFAR_batch(f)
        images_train.append(image_batch)
        labels_train.append(label_batch)
        Xtrain = np.concatenate(images_train)
        Ytrain = np.concatenate(labels_train)
        del image_batch, label_batch
    Xtest, Ytest = load_CIFAR_batch(os.path.join(data_dir, 'test_batch'))
    print('finish loadding CIFAR-10 data')
    return Xtrain, Ytrain, Xtest, Ytest

data_dir = 'data/cifar'
Xtrain, Ytrain, Xtest, Ytest = load_CIFAR_data(data_dir)

parameters_path='data/parameters.txt'

Xtrain_normalize = Xtrain.astype('float32')/255.0
Xtest_normalize = Xtest.astype('float32')/255.0
print(Xtrain_normalize[0][0][0])
encoder = OneHotEncoder(sparse=False,categories='auto')
yy = [[0],[1],[2],[3],[4],[5],[6],[7],[8],[9]]
encoder.fit(yy)

Ytrain_reshpe = Ytrain.reshape(-1,1)
Ytest_reshpe = Ytest.reshape(-1,1)

Ytrain_onehot = encoder.transform(Ytrain_reshpe)
Ytest_onehot = encoder.transform(Ytest_reshpe)

def weight(shape):
    return tf.Variable(tf.truncated_normal(shape,stddev=0.1),name='W')

def bias(shape):
    return tf.Variable(tf.constant(0.1,shape=shape),name='b')


def conv2d(x,W):
    return tf.nn.conv2d(x,W,strides=[1,1,1,1],padding="SAME")

def max_pool(x):
    return tf.nn.max_pool(x,ksize=[1,3,3,1],strides=[1,2,2,1],padding='SAME')
def avg_pool(x):
    return tf.nn.avg_pool(x,ksize=[1,3,3,1],strides=[1,2,2,1],padding='SAME')

# 输入层
with tf.name_scope('inputt_layer'):
    x = tf.placeholder('float', shape=[None, 32, 32, 3], name='X')

# 第一个卷积层
with tf.name_scope('conv_1'):
    W1 = weight([5, 5, 3, 32]) 
    b1 = bias([32])
    conv_1 = tf.nn.relu(conv2d(x, W1) + b1)
x_input = tf.reshape(x, [-1, 32, 32, 3])
tf.summary.image('input', x_input, max_outputs=4)
img_conv1 = W1[:, :, :, 0:1]
tf.summary.image('conv1', img_conv1, max_outputs=4)

# 第一个池化层
with tf.name_scope('pool_1'):
    pool_1 = max_pool(conv_1)

# 第二个卷积层
with tf.name_scope('conv_2'):
    W2 = weight([5, 5, 32, 32]) 
    b2 = bias([32])  
    conv_2 = tf.nn.relu(conv2d(pool_1, W2) + b2)

# 第二个池化层
with tf.name_scope('pool_2'):
    pool_2 = avg_pool(conv_2)

# 第三个卷积层
with tf.name_scope('conv_3'):
    W3 = weight([5, 5, 32, 64]) 
    b3 = bias([64]) 
    conv_3 = tf.nn.relu(conv2d(pool_2, W3) + b3)

# 第三个池化层
with tf.name_scope('pool_2'):
    pool_3 = avg_pool(conv_3)


with tf.name_scope('fc'):
    W3 = weight([1024,80])
    b3 = bias([80])
    flat = tf.reshape(pool_3, [-1, 1024])
    h = tf.nn.relu(tf.matmul(flat, W3) + b3)


with tf.name_scope('output_layer'):
    W4 = weight([80, 10])
    b4 = bias([10])
    pred = tf.nn.softmax(tf.matmul(h, W4) + b4)



with tf.name_scope('optimizer'):
    y = tf.placeholder('float',shape=[None,10],name='label')
    loss_fun = tf.reduce_mean(
        tf.nn.softmax_cross_entropy_with_logits
        (logits=pred,labels=y))
    lr = 0.0002
    opt = tf.train.AdamOptimizer(lr).minimize(loss_fun)


with tf.name_scope('evaluation'):
    correct_prediction = tf.equal(tf.argmax(pred,1),tf.argmax(y,1))
    accuracy = tf.reduce_mean(tf.cast(correct_prediction,'float'))


def next_epoch(num, batch_size):
    index = np.random.randint(0,num-1,batch_size)
    batch_x = Xtrain_normalize[index]
    batch_y = Ytrain_onehot[index]
    return batch_x,batch_y
def next_epoch1(num, batch_size):
    index = np.random.randint(0,num-1,batch_size)
    batch_x = Xtest_normalize[index]
    batch_y = Ytest_onehot[index]
    return batch_x,batch_y


train_epochs =20
batch_size = 50
total_batch = int(len(Xtrain) / batch_size)
display_step = 1
epoch_list = []
accuracy_list = []
loss_list = []
test_acc_list=[]
test_loss_list=[]
init = tf.global_variables_initializer() 

#开启会话
print("-------start--------")
with tf.Session() as sess:
    sess.run(init)
    writer = tf.summary.FileWriter(r'.\cifar-10\logs', sess.graph)
    merged = tf.summary.merge_all()
    for epoch in range(train_epochs):
        for i in range(total_batch):
            batch_x, batch_y = next_epoch(50000, batch_size)
            sess.run(opt, feed_dict={x: batch_x, y: batch_y})
        summary,loss, acc = sess.run([merged,loss_fun, accuracy], feed_dict={x: batch_x, y: batch_y})
        writer.add_summary(summary,epoch)
        if epoch % display_step == 0:
            print("Train Epoch:%02d" % (epoch + 1), "Loss=%f" % loss, "Accuracy=%.4f" % acc)
        epoch_list.append(epoch + 1)
        loss_list.append(loss)
        accuracy_list.append(acc)
        file = open(parameters_path, 'w')
        for v in tf.trainable_variables():
            file.write("全部参数"+"\n")
            file.write(str(v.eval()))
        file.close()

        #计算测试集上的准确率
        accuary_sum = 0
        sample_sum = 0
        test_acc_sum = 0
        test_loss_sum = 0
        test_total_batch = int(len(Xtest_normalize) / batch_size)
        for i in range(test_total_batch):
            test_image_batch = Xtest_normalize[i * batch_size:(i + 1) * batch_size]
            test_label_batch = Ytest_onehot[i * batch_size:(i + 1) * batch_size]
        test_batch_loss,test_batch_acc = sess.run([loss_fun,accuracy], feed_dict={x: test_image_batch, y: test_label_batch})
        test_acc_list.append(test_batch_acc)
        test_loss_list.append(test_batch_loss)
    batch_x, batch_y = next_epoch1(10000, batch_size)
    prediction_result = sess.run(tf.argmax(pred, 1), feed_dict={x: batch_x})
    label = sess.run(tf.argmax(batch_y, 1))


#损失曲线loss curve
fig = plt.gcf()
fig.set_size_inches(4,2)
plt.plot(loss_list,label='loss curve')
plt.ylabel('loss')
plt.xlabel('epoch')
plt.title('loss curve')
plt.legend(['loss'],loc='upper right')
plt.show()

#精度曲线accuracy curve
plt.plot(epoch_list,accuracy_list,label="accuracy curve")
fig=plt.gcf()
fig.set_size_inches(4,2)
plt.ylim(0.1,1)
plt.ylabel("accuracy")
plt.xlabel('epoch')
plt.title('accuracy curve')
plt.legend()
plt.show()
