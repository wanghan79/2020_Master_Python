
import argparse
import glob
from os import listdir, remove, makedirs
from os.path import exists, join, basename
import h5py

import numpy as np
from PIL import Image
from torchvision.transforms import Compose, CenterCrop, ToTensor, Resize

def get_h5file_path(images_dir, scale, save_dir):
    if not exists(save_dir):  makedirs(save_dir)
    h5file_path = join(save_dir ,"{}_x{}".format(basename(images_dir.strip('/\\')), scale))
    return h5file_path

def get_image(image, scale):
    y = image.convert('YCbCr').split()[0]
    small_size = y.height // scale, y.width // scale
    valid_size = small_size[0] * scale, small_size[1] *scale
    hr_image = CenterCrop(valid_size)(y)
    lr_image = Resize(small_size, Image.BICUBIC)(hr_image)

    hr_image = np.array(ToTensor()(hr_image))
    lr_image = np.array(ToTensor()(lr_image))
    return hr_image, lr_image

def create_dataset(images_dir, scale, save_dir='dataset'):
    h5_file = h5py.File(get_h5file_path(images_dir, scale, save_dir), 'w')
    hr_group = h5_file.create_group('hr')
    lr_group = h5_file.create_group('lr')
    for i, image_path in enumerate(glob.glob('{}/*.bmp'.format(images_dir.strip('\\/')))):
        rgb = Image.open(image_path).convert('RGB')
        hr_image, lr_image = get_image(rgb, scale)
        hr_group.create_dataset(str(i), data=hr_image)
        lr_group.create_dataset(str(i), data=lr_image)
    h5_file.close()

def create_dataset_aug(images_dir, scale, save_dir='dataset'):
    h5_file = h5py.File(get_h5file_path(images_dir, scale, save_dir)+'_aug6x', 'w')
    hr_images = []
    lr_images = []
    for i, image_path in enumerate(glob.glob('{}/*.bmp'.format(images_dir.strip('\\/')))):
        rgb = Image.open(image_path).convert('RGB')
        rgbs = []
        for s in [1.0, 0.9, 0.8]:
            for r in [0, 90]:
                tmp = Resize((int(rgb.height * s), int(rgb.width * s)), Image.BICUBIC)(rgb)
                tmp = tmp.rotate(r, expand=True)
                rgbs.append(tmp)
        for img in rgbs:
            hr_image, lr_image = get_image(img, scale)
            hr_images.append(hr_image)
            lr_images.append(lr_image)
    hr_group = h5_file.create_group('hr')
    lr_group = h5_file.create_group('lr')
    for i in range(len(hr_images)):
        hr_group.create_dataset(str(i), data=hr_images[i])
        lr_group.create_dataset(str(i), data=lr_images[i])
    h5_file.close()

    h5_file = h5py.File(get_h5file_path(images_dir, scale, save_dir)+'_aug20x', 'w')
    hr_images = []
    lr_images = []
    for i, image_path in enumerate(glob.glob('{}/*.bmp'.format(images_dir.strip('\\/')))):
        rgb = Image.open(image_path).convert('RGB')
        rgbs = []
        for s in [1.0, 0.9, 0.8, 0.7, 0.6]:
            for r in [0, 90, 180, 270]:
                tmp = Resize((int(rgb.height * s), int(rgb.width * s)), Image.BICUBIC)(rgb)
                tmp = tmp.rotate(r, expand=True)
                rgbs.append(tmp)
        for img in rgbs:
            hr_image, lr_image = get_image(img, scale)
            hr_images.append(hr_image)
            lr_images.append(lr_image)
    hr_group = h5_file.create_group('hr')
    lr_group = h5_file.create_group('lr')
    for i in range(len(hr_images)):
        hr_group.create_dataset(str(i), data=hr_images[i])
        lr_group.create_dataset(str(i), data=lr_images[i])
    h5_file.close()

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--train_dir', type=str, default="images/Set91")  #required=True)
    parser.add_argument('--eval_dir_1', type=str, default="images/Set14")  #required=True)
    parser.add_argument('--eval_dir_2', type=str, default="images/Set5")  #required=True)
    parser.add_argument('--scale', type=int, default=3)  #required=True)
    parser.add_argument('--aug', type=bool, default=False)  #required=True)
    parser.add_argument('--save_dir', type=str, default="dataset")  #required=True)
    args = parser.parse_args()

    print("Creating training {} h5_dataset...".format(basename(args.train_dir.strip('\\/'))))
    if args.aug:
        create_dataset_aug(args.train_dir, args.scale, args.save_dir)
    else:
        create_dataset(args.train_dir, args.scale, args.save_dir)
    print("Creating evaluation_1 {} h5_dataset...".format(basename(args.eval_dir_1.strip('\\/'))))
    create_dataset(args.eval_dir_1, args.scale, args.save_dir)
    print("Creating evaluation_2 {} h5_dataset...".format(basename(args.eval_dir_2.strip('\\/'))))
    create_dataset(args.eval_dir_2, args.scale, args.save_dir)
    print("Svae in directory: '{}', operation complete".format(args.save_dir))