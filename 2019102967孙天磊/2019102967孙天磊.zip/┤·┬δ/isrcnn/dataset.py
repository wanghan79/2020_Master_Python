
import h5py
from torch.utils.data import Dataset

class FormDataset(Dataset):
    def __init__(self, h5_file):
        super(FormDataset, self).__init__()
        self.h5_file = h5_file

    def __getitem__(self, index):
        with h5py.File(self.h5_file, 'r') as f:
            return f['lr'][str(index)][:], f['hr'][str(index)][:]

    def __len__(self):
        with h5py.File(self.h5_file, 'r') as f:
            return len(f['lr'])

def get_training_set(train_file):
    return FormDataset(train_file)

def get_evaluation_set(eval_file):
    return FormDataset(eval_file)