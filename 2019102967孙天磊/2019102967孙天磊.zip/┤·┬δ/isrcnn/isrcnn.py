
import os
import copy
import torch
import argparse
import torch.optim as optim
import torch.backends.cudnn as cudnn
from torch import nn
from tqdm import tqdm
from torch.utils.data.dataloader import DataLoader

from model import ISRCNN
from dataset import get_training_set, get_evaluation_set

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--d', type=int, default=56, help='dimensions of extracted features in the first part')
    parser.add_argument('--s', type=int, default=12, help='dimensions of shrinked features in the second part')
    parser.add_argument('--m', type=int, default=4, help='number of none-liner mappings in the second part')
    parser.add_argument('--train_dir', type=str, default="dataset/Set91_x3_aug6x")  # required=True)
    parser.add_argument('--eval_dir_1', type=str, default="dataset/Set14_x3")  # required=True)
    parser.add_argument('--eval_dir_2', type=str, default="dataset/Set5_x3")  # required=True)
    parser.add_argument('--save_dir', type=str, default="models")  # required=True)
    parser.add_argument('--scale', type=int, default=3)
    parser.add_argument('--lr', type=float, default=1e-3)
    parser.add_argument('--batch_size', type=int, default=1)  # 25)  # 
    parser.add_argument('--num_workers', type=int, default=0)
    parser.add_argument('--num_epochs', type=int, default=300)
    parser.add_argument('--seed', type=int, default=123)
    parser.add_argument('--tag', type=str, default='(8)lr')
    args = parser.parse_args()

    save_dir_root = args.save_dir
    add = "x{} {}.{}.{}  Set14__  {} {}".format(args.scale,args.d,args.s,args.m,args.num_epochs,args.tag)
    args.save_dir = os.path.join(args.save_dir, add).rstrip()
    print(args.tag,args.d,args.s,args.m,args.lr,args.scale,args.num_epochs)
    if not os.path.exists(args.save_dir): os.makedirs(args.save_dir)
    train_dir = args.train_dir.strip('/\\')
    eval_dir_1 = args.eval_dir_1.strip('/\\')
    eval_dir_2 = args.eval_dir_2.strip('/\\')
    # ===========================================================
    # Load train and evaluate dataset
    # ===========================================================
    train_dataset = get_training_set(args.train_dir)
    eval_dataset_1 = get_evaluation_set(args.eval_dir_1)
    eval_dataset_2 = get_evaluation_set(args.eval_dir_2)
    train_dataloader = DataLoader(dataset=train_dataset,
                                batch_size=args.batch_size,
                                shuffle=True,
                                num_workers=args.num_workers)
    eval_dataloader_1 = DataLoader(dataset=eval_dataset_1, 
                                batch_size=1, 
                                shuffle=False, 
                                num_workers=0)
    eval_dataloader_2 = DataLoader(dataset=eval_dataset_2, 
                                batch_size=1, 
                                shuffle=False, 
                                num_workers=0)

    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    cudnn.benchmark = True
    torch.manual_seed(args.seed)
    # ===========================================================
    # Build a ISRCNN model
    # ===========================================================
    model = ISRCNN(scale=args.scale, d=args.d, s=args.s, m=args.m).to(device)
    criterion = nn.MSELoss()
    #optimizer = optim.Adam(model.parameters(), lr=args.lr)
    #scheduler = torch.optim.lr_scheduler.MultiStepLR(optimizer, milestones=[75,200,400,700,1000,1300], gamma=0.5)

    optimizer = optim.Adam([
        {'params': model.first_part.parameters()},
        {'params': model.mid_part.parameters()},
        {'params': model.last_part.parameters(), 'lr': args.lr*0.1}
    ], lr=args.lr)
    scheduler = torch.optim.lr_scheduler.MultiStepLR(optimizer, milestones=[50,150,250], gamma=0.5)

    # ===========================================================
    # Some functions to save, train, and evaluate
    # ===========================================================
    def save_model(best_model, best_weights, best_psnr, eval_dir, best_epoch, num_epochs):
        model_save_path = os.path.join(args.save_dir, "{:4f}__m__x{}__{}__ep{}of{}.pth".format(
                best_psnr, args.scale, os.path.basename(eval_dir), best_epoch, num_epochs))
        weights_save_path = os.path.join(args.save_dir, "{:4f}__w__x{}__{}__ep{}of{}.pth".format(
                best_psnr, args.scale, os.path.basename(eval_dir), best_epoch, num_epochs))
        torch.save(best_model, model_save_path)
        torch.save(best_weights, weights_save_path)
        print("Checkpoint saved to\t{}\n\t\t\t{}".format(model_save_path, weights_save_path))
        pass

    def save_psnr(psnr_record, best_psnr, eval_dir, best_epoch, num_epochs):
        psnr_save_path = os.path.join(args.save_dir, "psnr__{:4f}__x{}__{}__ep{}of{}.txt".format(
                best_psnr, args.scale, os.path.basename(eval_dir), best_epoch, num_epochs))
        with open(psnr_save_path, 'w') as f: f.write(str(psnr_record))
        print("{} psnr saved to {}".format(os.path.basename(eval_dir), psnr_save_path))
        pass

    def save_loss(loss_record, train_dir, num_epochs):
        loss_save_path = os.path.join(args.save_dir, "loss__x{}__{}__ep{}.txt".format(
                args.scale, os.path.basename(train_dir), num_epochs))
        with open(loss_save_path, 'w') as f: f.write(str(loss_record))
        print("loss saved to {}".format(loss_save_path))
        pass
    
    def train(model, train_dataloader):
        epoch_sum_loss = 0; epoch_avg_loss = 0
        # Create progress bar
        with tqdm(total=(len(train_dataset) - len(train_dataset) % args.batch_size)) as t:
            t.set_description('epoch:{}/{}'.format(epoch, args.num_epochs))
            # Training in the one epoch
            for batch_num, (inputs, labels) in enumerate(train_dataloader):
                inputs, labels = inputs.to(device), labels.to(device)
                optimizer.zero_grad()
                loss = criterion(model(inputs), labels)
                epoch_sum_loss += loss.item()
                epoch_avg_loss = epoch_sum_loss / (batch_num + 1)
                # Backpropagation and optimization
                loss.backward()
                optimizer.step()
                # Update progress bar
                t.set_postfix(loss='{:.6f}'.format(epoch_avg_loss))
                t.update(len(inputs))
        return epoch_avg_loss

    def evaluate(model, eval_dataloader):
        epoch_sum_psnr = 0; epoch_avg_psnr = 0
        for batch_num, (inputs, labels) in enumerate(eval_dataloader):
            inputs, labels = inputs.to(device), labels.to(device)
            with torch.no_grad(): prediction = model(inputs)
            mse = criterion(prediction, labels)
            epoch_sum_psnr += (10 * torch.log10(1 / mse)).item()
            epoch_avg_psnr = epoch_sum_psnr / (batch_num + 1)
        return epoch_avg_psnr
    # ===========================================================
    # Some variables to get the best model
    # ===========================================================
    best_epoch_1 = 0; best_psnr_1 = 0
    best_epoch_2 = 0; best_psnr_2 = 0
    best_model_1 = None; best_weights_1 = copy.deepcopy(model.state_dict())
    best_model_2 = None; best_weights_2 = copy.deepcopy(model.state_dict())
    loss_record = []
    psnr_record_1 = []; psnr_record_2 = []
    # ===========================================================
    # Start model training and evaluation
    # ===========================================================
    for epoch in range(1, args.num_epochs + 1):
        model.train()
        epoch_avg_loss = train(model, train_dataloader)
        loss_record.append(epoch_avg_loss)
        model.eval()
        # evaluation set 1 (Set14)
        epoch_avg_psnr_1 = evaluate(model, eval_dataloader_1)
        psnr_record_1.append(epoch_avg_psnr_1)
        print('test psnr on {}: {:.4f}'.format(os.path.basename(eval_dir_1), epoch_avg_psnr_1))
        # evaluation set 2 (Set5)
        epoch_avg_psnr_2 = evaluate(model, eval_dataloader_2)
        psnr_record_2.append(epoch_avg_psnr_2)
        print('test psnr on {}: {:.4f}'.format(os.path.basename(eval_dir_2), epoch_avg_psnr_2))
        # schedul learning rate
        scheduler.step()
        # print('lr:', optimizer.state_dict()['param_groups'][0]['lr'])

        if epoch_avg_psnr_1 > best_psnr_1:
            best_epoch_1 = epoch
            best_psnr_1 = epoch_avg_psnr_1
            best_model_1 = model
            best_weights_1 = copy.deepcopy(model.state_dict())
        if epoch_avg_psnr_2 > best_psnr_2:
            best_epoch_2 = epoch
            best_psnr_2 = epoch_avg_psnr_2
            best_model_2 = model
            best_weights_2 = copy.deepcopy(model.state_dict())
        if epoch % 50 == 0 and epoch != args.num_epochs:
            print('up to epoch-{}'.format(epoch))
            print('best test psnr on {}: {:.4f} (epoch-{})'.format(os.path.basename(eval_dir_1), best_psnr_1, best_epoch_1))
            print('best test psnr on {}: {:.4f} (epoch-{})'.format(os.path.basename(eval_dir_2), best_psnr_2, best_epoch_2))
            save_model(best_model_1, best_weights_1, best_psnr_1, eval_dir_1, best_epoch_1, epoch)
            save_model(best_model_2, best_weights_2, best_psnr_2, eval_dir_2, best_epoch_2, epoch)
    print('at the end epoch-{}'.format(args.num_epochs))
    print('best test psnr on {}: {:.4f} (epoch-{})'.format(os.path.basename(eval_dir_1), best_psnr_1, best_epoch_1))
    print('best test psnr on {}: {:.4f} (epoch-{})'.format(os.path.basename(eval_dir_2), best_psnr_2, best_epoch_2))
    save_model(best_model_1, best_weights_1, best_psnr_1, eval_dir_1, best_epoch_1, args.num_epochs)
    save_model(best_model_2, best_weights_2, best_psnr_2, eval_dir_2, best_epoch_2, args.num_epochs)
    save_psnr(psnr_record_1, best_psnr_1, eval_dir_1, best_epoch_1, args.num_epochs)
    save_psnr(psnr_record_2, best_psnr_2, eval_dir_2, best_epoch_2, args.num_epochs)
    save_loss(loss_record, train_dir, args.num_epochs)

    add2 = "x{} {}.{}.{}  Set14__{:4f} Set5__{:4f}  {} {}".format(args.scale,args.d,args.s,args.m, best_psnr_1, best_psnr_2, args.num_epochs, args.tag)
    save_dir2 = os.path.join(save_dir_root, add2).rstrip()
    os.rename(args.save_dir, save_dir2)
    print('dir: {}'.format(save_dir2))
    print("End")