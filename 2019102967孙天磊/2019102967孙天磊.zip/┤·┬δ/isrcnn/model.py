
import math
from torch import nn

class ISRCNN(nn.Module):
    def __init__(self, scale, d=56, s=12, m=4, num_channels=1):
        super(ISRCNN, self).__init__()
        self.first_part = nn.Sequential(
            nn.Conv2d(in_channels=num_channels, out_channels=d, kernel_size=5, padding=5//2),  # padding = 0 ?
            nn.PReLU())

        self.mid_part = [
            nn.Conv2d(in_channels=d, out_channels=s, kernel_size=1, padding=1//2), 
            nn.PReLU()]
        for _ in range(m):
            self.mid_part.extend([
                nn.Conv2d(in_channels=s, out_channels=s, kernel_size=3, padding=3//2), 
                nn.PReLU()])
        self.mid_part.extend([
            nn.Conv2d(in_channels=s, out_channels=d, kernel_size=1, padding=1//2), 
            nn.PReLU()])
        self.mid_part = nn.Sequential(*self.mid_part)

        self.last_part = nn.ConvTranspose2d(in_channels=d, out_channels=num_channels, kernel_size=9, 
                                            stride=scale, padding=9//2, output_padding=scale-1)
        self._init_weights()

    def _init_weights(self):
        for m in self.first_part:
            if isinstance(m, nn.Conv2d):
                nn.init.normal_(m.weight.data, mean=0.0, std=math.sqrt(2/(m.out_channels*m.weight.data[0][0].numel())))
                nn.init.zeros_(m.bias.data)
        for m in self.mid_part:
            if isinstance(m, nn.Conv2d):
                nn.init.normal_(m.weight.data, mean=0.0, std=math.sqrt(2/(m.out_channels*m.weight.data[0][0].numel())))
                nn.init.zeros_(m.bias.data)
        nn.init.normal_(self.last_part.weight.data, mean=0.0, std=0.001)
        nn.init.zeros_(self.last_part.bias.data)

    def forward(self, x):
        x = self.first_part(x)
        x = self.mid_part(x)
        x = self.last_part(x)
        return x