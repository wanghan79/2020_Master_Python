
import argparse
import glob
import torch
import torch.backends.cudnn as cudnn
import numpy as np
from PIL import Image
from os import listdir, remove, makedirs
from os.path import exists, join, basename
from torchvision.transforms import Compose, CenterCrop, ToTensor, Resize
import time
# from model import SRCNN

parser = argparse.ArgumentParser()
parser.add_argument('--images_dir', type=str, default='images/Set14')
parser.add_argument('--model', type=str, default='x3.pth') # required=True)
parser.add_argument('--scale', type=int, default=3) # required=True)
parser.add_argument('--output_dir', type=str, default='sr_output')
parser.add_argument('--srcnn', type=bool, default=True)
args = parser.parse_args()

scale = args.scale
add = '{}_{}'.format(basename(args.model.rstrip('.pth\\/')),basename(args.images_dir.rstrip('\\/')))
save_dir = join(args.output_dir, add)
if not exists(save_dir): makedirs(save_dir)
#
cudnn.benchmark = True
device = torch.device('cuda: 0' if torch.cuda.is_available() else 'cpu')
#device = torch.device('cpu')
model = torch.load(args.model, map_location=lambda storage, loc: storage)
model = model.to(device)

def cal_bicubic(hr_image, bic_image):
    hr_y = hr_image.convert('YCbCr').split()[0]
    bic_y = bic_image.convert('YCbCr').split()[0]
    hr_yt = ToTensor()(hr_y)
    bic_yt = ToTensor()(bic_y)
    return 10. * torch.log10(1. / torch.mean((hr_yt - bic_yt) ** 2))

sr_sum_psnr = 0.
sr_avg_psnr = 0.
times = []
for i, image_path in enumerate(glob.glob('{}/*.bmp'.format(args.images_dir.strip('\\/')))):
    image_name = basename(image_path).rstrip('.bmp')
    image = Image.open(image_path).convert('RGB')
    h = image.height;    w = image.width
    small_size = h//scale, w//scale
    valid_size = h//scale*scale, w//scale*scale
    hr_image = CenterCrop(valid_size)(image)
    hr_image.save(join(save_dir, '0{}_origin.bmp'.format(image_name)))
    # LR image 输入网络的LR图像
    lr_image = Resize(small_size, Image.BICUBIC)(hr_image)
    if args.srcnn: lr_image = Resize(valid_size, Image.BICUBIC)(hr_image)
    # bicubic 重建计算PSNR和保存
    bic_image = Resize(valid_size, Image.BICUBIC)(lr_image)
    bic_image.save(join(save_dir, '1{}_bicubic_x{}.bmp'.format(image_name, scale)))

    # isrcnn 重建计算PSNR和保存
    lr_y, lr_cb, lr_cr = lr_image.convert('YCbCr').split()
    hr_y, hr_cb, hr_cr = hr_image.convert('YCbCr').split()
    label = (ToTensor()(hr_y)).unsqueeze(0).to(device)  # view(1, -1, hr_y.size[1], hr_y.size[0])
    data = (ToTensor()(lr_y)).unsqueeze(0).to(device)
    s = time.clock()
    with torch.no_grad(): pred = model(data)
    e = time.clock()
    times.append(e-s)
    sr_psnr = 10. * torch.log10(1. / torch.mean((label - pred) ** 2))
    sr_sum_psnr += sr_psnr;    sr_avg_psnr = sr_sum_psnr/(i+1)
    pred = pred.cpu().squeeze(0).squeeze(0) #.squeeze(0).squeeze(0) #
    sr_y = Image.fromarray(np.uint8((pred.numpy()*255.0).clip(0, 255)),'L')
    sr_image = Image.merge('YCbCr', [sr_y, hr_cb, hr_cr]).convert('RGB')
    sr_image.save(join(save_dir, '2{}_srcnn_x{}_psnr{:2f}.bmp'.format(image_name, scale, sr_psnr)))
    

    print(image_name, '{:2f}'.format(sr_psnr.item()))
    
# print('{:2f}'.format(sr_avg_psnr.item()))
print(sum(times), sum(times)/len(times))