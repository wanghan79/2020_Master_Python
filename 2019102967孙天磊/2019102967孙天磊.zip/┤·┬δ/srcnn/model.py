
from torch import nn

class SRCNN(nn.Module):
    def __init__(self, num_channels=1):
        super(SRCNN, self).__init__()

        self.first_part = nn.Sequential(
            nn.Conv2d(in_channels=num_channels, out_channels=64, kernel_size=9, padding=9 // 2),
            nn.ReLU(inplace=True)
        )
        self.mid_part = nn.Sequential(
            nn.Conv2d(in_channels=64, out_channels=32, kernel_size=5, padding=5 // 2),
            nn.ReLU(inplace=True)
        )
        self.last_part = nn.Conv2d(in_channels=32, out_channels=num_channels, kernel_size=5, padding=5 // 2)

        self._init_weights()

    def _init_weights(self):
        for m in self.first_part:
            if isinstance(m, nn.Conv2d):
                nn.init.normal_(m.weight.data, mean=0.0, std=0.001)
                nn.init.zeros_(m.bias.data)
        for m in self.mid_part:
            if isinstance(m, nn.Conv2d):
                nn.init.normal_(m.weight.data, mean=0.0, std=0.001)
                nn.init.zeros_(m.bias.data)
        nn.init.normal_(self.last_part.weight.data, mean=0.0, std=0.001)
        nn.init.zeros_(self.last_part.bias.data)

    def forward(self, x):
        x = self.first_part(x)
        x = self.mid_part(x)
        x = self.last_part(x)
        return x