from cx_Freeze import setup, Executable
 
 
setup(name='Flappy bird',
      version = '1.0',
      description='Flappy bird',
      executables = [Executable("main.py",base = "Win32GUI",icon = "flappy.ico")]
 
      )
