from itertools import cycle
import random
import sys
import pygame
from pygame.locals import *

BirdSpeed = 20
Window_Width = 288
Window_Height = 512
PipeSize = 100  # 管子上下间隙
BASEY = Window_Height * 0.80  # 地面上绿色条条的位置
IMAGES, SOUNDS, HITMASKS = {}, {}, {}
# 调用游戏里需要的所有图片
Players_List = (
    # 红色小鸟
    (
        'a/image/redbird-upflap.png',
        'a/image/redbird-midflap.png',
        'a/image/redbird-downflap.png',
    ),
    # 蓝色小鸟
    (
        'a/image/bluebird-upflap.png',
        'a/image/bluebird-midflap.png',
        'a/image/bluebird-downflap.png',
    ),
    # 黄色小鸟
    (
        'a/image/yellowbird-upflap.png',
        'a/image/yellowbird-midflap.png',
        'a/image/yellowbird-downflap.png',
    ),
)
# 调用背景图
Backgrounds_List = (
    'a/image/background-day.png',
    'a/image/background-night.png',
)
# 调用管道图
Pipes_List = (
    'a/image/pipe-green.png',
    'a/image/pipe-red.png',
)
try:
    xrange
except NameError:
    xrange = range


def main():
    global Screen, FPSCLOCK
    pygame.init()
    FPSCLOCK = pygame.time.Clock()  # 创建时钟对象 (可以控制游戏循环频率)
    Screen = pygame.display.set_mode((Window_Width, Window_Height))  # 屏幕大小
    # 显示分数
    IMAGES['numbers'] = (
        pygame.image.load('a/image/0.png').convert_alpha(),
        pygame.image.load('a/image/1.png').convert_alpha(),
        pygame.image.load('a/image/2.png').convert_alpha(),
        pygame.image.load('a/image/3.png').convert_alpha(),
        pygame.image.load('a/image/4.png').convert_alpha(),
        pygame.image.load('a/image/5.png').convert_alpha(),
        pygame.image.load('a/image/6.png').convert_alpha(),
        pygame.image.load('a/image/7.png').convert_alpha(),
        pygame.image.load('a/image/8.png').convert_alpha(),
        pygame.image.load('a/image/9.png').convert_alpha()
    )
    # 欢迎界面
    IMAGES['message'] = pygame.image.load('a/image/message.png').convert_alpha()
    # 界面基础
    IMAGES['base'] = pygame.image.load('a/image/base.png').convert_alpha()
    # 调用声音
    soundExt = '.wav'
    SOUNDS['die'] = pygame.mixer.Sound('a/audio/die' + soundExt)
    SOUNDS['hit'] = pygame.mixer.Sound('a/audio/hit' + soundExt)
    SOUNDS['point'] = pygame.mixer.Sound('a/audio/point' + soundExt)
    SOUNDS['swoosh'] = pygame.mixer.Sound('a/audio/swoosh' + soundExt)
    SOUNDS['wing'] = pygame.mixer.Sound('a/audio/wing' + soundExt)
    while True:
        # 随机选择背景
        randBg = random.randint(0, len(Backgrounds_List) - 1)
        IMAGES['background'] = pygame.image.load(Backgrounds_List[randBg]).convert()

        # 选择随机的小鸟
        randPlayer = random.randint(0, len(Players_List) - 1)
        IMAGES['player'] = (
            pygame.image.load(Players_List[randPlayer][0]).convert_alpha(),
            pygame.image.load(Players_List[randPlayer][1]).convert_alpha(),
            pygame.image.load(Players_List[randPlayer][2]).convert_alpha(),
        )
        # 管道随机
        pipeindex = random.randint(0, len(Pipes_List) - 1)
        IMAGES['pipe'] = (
            pygame.transform.rotate(
                pygame.image.load(Pipes_List[pipeindex]).convert_alpha(), 180),
            pygame.image.load(Pipes_List[pipeindex]).convert_alpha(),
        )
        HITMASKS['pipe'] = (
            getHitmask(IMAGES['pipe'][0]),
            getHitmask(IMAGES['pipe'][1]),
        )
        HITMASKS['player'] = (
            getHitmask(IMAGES['player'][0]),
            getHitmask(IMAGES['player'][1]),
            getHitmask(IMAGES['player'][2]),
        )
        movementInfo = showWelcomeAnimation()
        crashInfo = mainGame(movementInfo)


def showWelcomeAnimation():
    # 显示欢迎界面动画的鸟
    playerIndex = 0
    playerIndexGen = cycle([0, 1, 2, 1])
    # 迭代器变化
    loopIter = 0
    # player所在位置
    playerx = int(Window_Width * 0.2)
    playery = int((Window_Height - IMAGES['player'][0].get_height()) / 2)
    # 欢迎图像所在位置
    messagex = int((Window_Width - IMAGES['message'].get_width()) / 2)
    messagey = int(Window_Height * 0.12)
    basex = 0
    # 向左移动的距离
    baseShift = IMAGES['base'].get_width() - IMAGES['background'].get_width()
    # 角色在屏幕上上下移动
    playerShmVals = {'val': 0, 'dir': 1}
    while True:
        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()
                sys.exit()
            if event.type == KEYDOWN and (event.key == K_SPACE or event.key == K_UP):
                SOUNDS['wing'].play()
                return {
                    'playery': playery + playerShmVals['val'],
                    'basex': basex,
                    'playerIndexGen': playerIndexGen,
                }
        if (loopIter + 1) % 5 == 0:
            playerIndex = next(playerIndexGen)
        loopIter = (loopIter + 1) % 30
        basex = -((-basex + 4) % baseShift)
        playerShm(playerShmVals)
        # 绘制
        Screen.blit(IMAGES['background'], (0, 0))
        Screen.blit(IMAGES['message'], (messagex, messagey))
        Screen.blit(IMAGES['base'], (basex, BASEY))
        pygame.display.update()


def mainGame(movementInfo):
    score = playerIndex = loopIter = 0
    playerIndexGen = movementInfo['playerIndexGen']
    playerx, playery = int(Window_Width * 0.2), movementInfo['playery']
    basex = movementInfo['basex']
    baseShift = IMAGES['base'].get_width() - IMAGES['background'].get_width()
    # 获得2个新的管道添加到上管，下管列表
    newPipe1 = getRandomPipe()
    newPipe2 = getRandomPipe()
    # 上管列表
    upperPipes = [
        {'x': Window_Width + 200, 'y': newPipe1[0]['y']},
        {'x': Window_Width + 200 + (Window_Width / 2), 'y': newPipe2[0]['y']},
    ]
    # 下管列表
    lowerPipes = [
        {'x': Window_Width + 200, 'y': newPipe1[1]['y']},
        {'x': Window_Width + 200 + (Window_Width / 2), 'y': newPipe2[1]['y']},
    ]
    pipeVelX = -4
    # 小鸟的速度，最大速度，向下的加速度，向上的加速度
    playerVelY = -9  # 小鸟的速度沿y轴，默认小鸟的拍打相同
    playerMaxVelY = 10  # 小鸟最大速度沿Y轴，最大下降速度
    playerMinVelY = -8  # 小鸟最小速度沿y轴，最大提升速度
    playerAccY = 1  # 小鸟向下的加速度
    playerRot = 45  # 小鸟的轮换
    playerVelRot = 3  # 角速度
    playerRotThr = 20
    playerFlapAcc = -9
    playerFlapped = False
    while True:
        for event in pygame.event.get():
            if event.type == QUIT or (event.type == KEYDOWN and event.key == K_ESCAPE):
                pygame.quit()
                sys.exit()
            if event.type == KEYDOWN and (event.key == K_SPACE or event.key == K_UP):
                if playery > -2 * IMAGES['player'][0].get_height():
                    playerVelY = playerFlapAcc
                    playerFlapped = True
                    SOUNDS['wing'].play()
        # 小鸟是否死亡
        crashTest = checkCrash({'x': playerx, 'y': playery, 'index': playerIndex},
                               upperPipes, lowerPipes)
        if crashTest[0]:
            return {
                'y': playery,
                'groundCrash': crashTest[1],
                'basex': basex,
                'upperPipes': upperPipes,
                'lowerPipes': lowerPipes,
                'score': score,
                'playerVelY': playerVelY,
                'playerRot': playerRot
            }
        # 评分
        playerMidPos = playerx + IMAGES['player'][0].get_width() / 2
        for pipe in upperPipes:
            pipeMidPos = pipe['x'] + IMAGES['pipe'][0].get_width() / 2
            if pipeMidPos <= playerMidPos < pipeMidPos + 4:
                score += 1
                SOUNDS['point'].play()
        if (loopIter + 1) % 3 == 0:
            playerIndex = next(playerIndexGen)
        loopIter = (loopIter + 1) % 30
        basex = -((-basex + 100) % baseShift)
        # 小鸟的运动
        if playerVelY < playerMaxVelY and not playerFlapped:
            playerVelY += playerAccY
        if playerFlapped:
            playerFlapped = False
            playerRot = 45
        playerHeight = IMAGES['player'][playerIndex].get_height()
        playery += min(playerVelY, BASEY - playery - playerHeight)
        # 向左边移动管道
        for uPipe, lPipe in zip(upperPipes, lowerPipes):
            uPipe['x'] += pipeVelX
            lPipe['x'] += pipeVelX
        # 当第一个管道即将接触屏幕左侧时添加新管道。
        if 0 < upperPipes[0]['x'] < 5:
            newPipe = getRandomPipe()
            upperPipes.append(newPipe[0])
            lowerPipes.append(newPipe[1])
        # 如果没有屏幕，移除第一个管道。
        if upperPipes[0]['x'] < -IMAGES['pipe'][0].get_width():
            upperPipes.pop(0)
            lowerPipes.pop(0)
        Screen.blit(IMAGES['background'], (0, 0))
        for uPipe, lPipe in zip(upperPipes, lowerPipes):
            Screen.blit(IMAGES['pipe'][0], (uPipe['x'], uPipe['y']))
            Screen.blit(IMAGES['pipe'][1], (lPipe['x'], lPipe['y']))
        Screen.blit(IMAGES['base'], (basex, BASEY))
        # 打印分数使玩家累积得分
        showScore(score)
        visibleRot = playerRotThr
        if playerRot <= playerRotThr:
            visibleRot = playerRot
        playerSurface = pygame.transform.rotate(IMAGES['player'][playerIndex], visibleRot)
        Screen.blit(playerSurface, (playerx, playery))
        pygame.display.update()
        FPSCLOCK.tick(BirdSpeed)


def playerShm(playerShm):
    """oscillates the value of playerShm['val'] between 8 and -8"""
    if abs(playerShm['val']) == 8:
        playerShm['dir'] *= -1
    if playerShm['dir'] == 1:
        playerShm['val'] += 1
    else:
        playerShm['val'] -= 1


def getRandomPipe():
    # 随机生成的管道高度
    # 上下管间隙
    gapY = random.randrange(0, int(BASEY * 0.6 - PipeSize))
    gapY += int(BASEY * 0.2)
    pipeHeight = IMAGES['pipe'][0].get_height()
    pipeX = Window_Width + 10
    return [
        {'x': pipeX, 'y': gapY - pipeHeight},  # 上管
        {'x': pipeX, 'y': gapY + PipeSize},  # 下管
    ]


def showScore(score):
    """在屏幕中间显示得分"""
    scoreDigits = [int(x) for x in list(str(score))]
    totalWidth = 0  # 所有要打印的数字的总宽度
    for digit in scoreDigits:
        totalWidth += IMAGES['numbers'][digit].get_width()
    Xoffset = (Window_Width - totalWidth) / 2
    for digit in scoreDigits:
        Screen.blit(IMAGES['numbers'][digit], (Xoffset, Window_Height * 0.1))
        Xoffset += IMAGES['numbers'][digit].get_width()


def checkCrash(player, upperPipes, lowerPipes):
    pi = player['index']
    player['w'] = IMAGES['player'][0].get_width()
    player['h'] = IMAGES['player'][0].get_height()
    # 如果玩家撞到地面
    if player['y'] + player['h'] >= BASEY - 1:
        return [True, True]
    else:
        playerRect = pygame.Rect(player['x'], player['y'],
                                 player['w'], player['h'])
        pipeW = IMAGES['pipe'][0].get_width()
        pipeH = IMAGES['pipe'][0].get_height()
        for uPipe, lPipe in zip(upperPipes, lowerPipes):
            # 上、下管矩形
            uPipeRect = pygame.Rect(uPipe['x'], uPipe['y'], pipeW, pipeH)
            lPipeRect = pygame.Rect(lPipe['x'], lPipe['y'], pipeW, pipeH)
            pHitMask = HITMASKS['player'][pi]
            uHitmask = HITMASKS['pipe'][0]
            lHitmask = HITMASKS['pipe'][1]
            # 如果鸟与管道相撞
            uCollide = pixelCollision(playerRect, uPipeRect, pHitMask, uHitmask)
            lCollide = pixelCollision(playerRect, lPipeRect, pHitMask, lHitmask)
            if uCollide or lCollide:
                return [True, False]
    return [False, False]


def pixelCollision(rect1, rect2, hitmask1, hitmask2):
    # 检查两个对象是否碰撞
    rect = rect1.clip(rect2)
    if rect.width == 0 or rect.height == 0:
        return False
    x1, y1 = rect.x - rect1.x, rect.y - rect1.y
    x2, y2 = rect.x - rect2.x, rect.y - rect2.y
    for x in xrange(rect.width):
        for y in xrange(rect.height):
            if hitmask1[x1 + x][y1 + y] and hitmask2[x2 + x][y2 + y]:
                return True
    return False


def getHitmask(image):
    mask = []
    for x in xrange(image.get_width()):
        mask.append([])
        for y in xrange(image.get_height()):
            mask[x].append(bool(image.get_at((x, y))[3]))
    return mask


if __name__ == '__main__':
    main()
