import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVR
import numpy as np
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error

x_train = pd.read_csv("X_train.csv", header=None, skiprows=0)    # 未pca
y_train = pd.read_csv("y_train.csv", header=None, skiprows=0)
x_test = pd.read_csv("X_test.csv", header=None, skiprows=0)
y_test = pd.read_csv("y_test.csv", header=None, skiprows=0)


ss_x = StandardScaler()
x_train = ss_x.fit_transform(x_train)
x_test = ss_x.transform(x_test)

ss_y = StandardScaler()
y_train = ss_y.fit_transform(y_train.values.reshape(-1, 1))
y_test = ss_y.transform(y_test.values.reshape(-1, 1))


# 线性核函数配置支持向量机
linear_svr = SVR(kernel="linear")
# 训练
linear_svr.fit(x_train, y_train)
# 预测 保存预测结果
linear_svr_y_predict = linear_svr.predict(x_test)


# 多项式核函数配置支持向量机
poly_svr = SVR(kernel="poly")
# 训练
poly_svr.fit(x_train, y_train)
# 预测 保存预测结果
poly_svr_y_predict = linear_svr.predict(x_test)

# 径向基核函数配置支持向量机
rbf_svr = SVR(kernel="rbf")
# 训练
rbf_svr.fit(x_train, y_train)
# 预测 保存预测结果
rbf_svr_y_predict = rbf_svr.predict(x_test)


print("线性核函数支持向量机的默认评估值为（训练集）：", linear_svr.score(x_train, y_train))
print("线性核函数支持向量机的默认评估值为（测试集）：", linear_svr.score(x_test, y_test))
print()

print("对多项式核函数的默认评估值为（训练集）：", poly_svr.score(x_train, y_train))
print("对多项式核函数的默认评估值为（测试集）：", poly_svr.score(x_test, y_test))
print()

print("对径向基核函数的默认评估值为（训练集）：", rbf_svr.score(x_train, y_train))
print("对径向基核函数的默认评估值为（测试集）：", rbf_svr.score(x_test, y_test))
print()


a = np.array(rbf_svr_y_predict)
b = np.array(poly_svr_y_predict)
c = np.array(linear_svr_y_predict)
ret = a+b+c
y_pred = ret/3


print("集成模型准确率：", r2_score(y_test, y_pred))

# print("平均绝对误差(MAE)为:", mean_absolute_error(ss_y.inverse_transform(y_test),
#                                             ss_y.inverse_transform(y_pred)))
