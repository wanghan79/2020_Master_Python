import pandas as pd
from sklearn.model_selection import train_test_split

data = pd.read_csv("merge.csv", header=None, skiprows=0)    # 读取merge.csv（5878x54），第一列为y值


# 给数据集添加标签，X:特征；y:预测值
X = data.iloc[:, 1:54]
y = data.iloc[:, 0]

# 用train_test_split函数划分出训练集和测试集，测试集占比0.2
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
# print(X_test)
# print(y_test)

csvFile = open("X_train.csv", "w")
X_train.to_csv('X_train.csv', index=False, header=None)

csvFile = open("y_train.csv", "w")
y_train.to_csv('y_train.csv', index=False, header=None)

csvFile = open("X_test.csv", "w")
X_test.to_csv('X_test.csv', index=False, header=None)

csvFile = open("y_test.csv", "w")
y_test.to_csv('y_test.csv', index=False, header=None)