from sklearn.neighbors import KNeighborsRegressor
from sklearn.preprocessing import StandardScaler
import pandas as pd
from sklearn.metrics import mean_squared_error, mean_absolute_error

# x_train = pd.read_csv("pca_X_train.csv", header=None, skiprows=0)  # 未归一化（测试集准确度高于归一化后：训练集40.27% 测试集41.02%）
# y_train = pd.read_csv("y_train.csv", header=None, skiprows=0)
# x_test = pd.read_csv("pca_X_test.csv", header=None, skiprows=0)
# y_test = pd.read_csv("y_test.csv", header=None, skiprows=0)

x_train = pd.read_csv("X_train.csv", header=None, skiprows=0)   # 未PCA  (精度高于pca后：训练集41.85% 测试集42.30%)
x_test = pd.read_csv("X_test.csv", header=None, skiprows=0)
y_train = pd.read_csv("y_train.csv", header=None, skiprows=0)
y_test = pd.read_csv("y_test.csv", header=None, skiprows=0)

# x_train = pd.read_csv("normalized_x_train.csv", header=None, skiprows=0)   # 归一化+PCA（训练集：41.28%  测试集：38.99%）
# y_train = pd.read_csv("y_train.csv", header=None, skiprows=0)
# x_test = pd.read_csv("normalized_x_test.csv", header=None, skiprows=0)
# y_test = pd.read_csv("y_test.csv", header=None, skiprows=0)

ss_x = StandardScaler()
x_train = ss_x.fit_transform(x_train)
x_test = ss_x.transform(x_test)
ss_y = StandardScaler()
y_train = ss_y.fit_transform(y_train.values.reshape(-1, 1))
y_test = ss_y.transform(y_test.values.reshape(-1, 1))


# k = 21
knn = KNeighborsRegressor(n_neighbors=21, weights='uniform',
                          algorithm='auto', leaf_size=20)

knn.fit(x_train, y_train)
train_score = knn.score(x_train, y_train, sample_weight=None)  # 计算拟合曲线针对训练样本的拟合准确性
print('训练集精度：', train_score)

fit1_predict = knn.predict(x_test)

test_score = knn.score(x_test, y_test, sample_weight=None)     # 计算拟合曲线针对测试样本的拟合准确性
print('测试集精度：', test_score)

print("MSE:", mean_squared_error(y_test, fit1_predict))
print("MAE:", mean_absolute_error(y_test, fit1_predict))

# # generate enough predict data
# y_pred = knn.predict(x_test)

for k in range(10, 50):
    knn = KNeighborsRegressor(k)
    knn.fit(x_train, y_train)
    train_score = knn.score(x_train, y_train, sample_weight=None)  # 计算拟合曲线针对训练样本的拟合准确性
    print
    print(k)
    print(train_score)
    test_score = knn.score(x_test, y_test, sample_weight=None)  # 计算拟合曲线针对测试样本的拟合准确性
    print(test_score)

# print(len(x_train))
# print(len(y_train))
# print(len(x_test))
# print(len(y_pred))
