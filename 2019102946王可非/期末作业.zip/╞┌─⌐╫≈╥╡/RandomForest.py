from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
import pandas as pd
from sklearn.metrics import accuracy_score

x_train = pd.read_csv("pca_X_train.csv", header=None, skiprows=0)
y_train = pd.read_csv("y_train.csv", header=None, skiprows=0)
x_test = pd.read_csv("pca_X_test.csv", header=None, skiprows=0)
y_test = pd.read_csv("y_test.csv", header=None, skiprows=0)

ss_x = StandardScaler()
x_train = ss_x.fit_transform(x_train)
x_test = ss_x.transform(x_test)
#
ss_y = StandardScaler()
y_train = ss_y.fit_transform(y_train.values.reshape(-1, 1))
y_test = ss_y.transform(y_test.values.reshape(-1, 1))

# 随机森林
clf2 = RandomForestClassifier(random_state=9)
model2 = clf2.fit(x_train, y_train.astype('int'))
print('随机森林训练集准确率 (%): ', accuracy_score(y_train.astype('int'), model2.predict(x_train), normalize=True))
print('随机森林测试集准确率 (%): ', accuracy_score(y_test.astype('int'), model2.predict(x_test), normalize=True))