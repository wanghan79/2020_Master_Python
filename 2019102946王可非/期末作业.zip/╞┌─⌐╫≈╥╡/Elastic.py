from sklearn import linear_model
import pandas as pd
from sklearn.metrics import mean_absolute_error

x_train = pd.read_csv("X_train.csv", header=None, skiprows=0)    # 未pca
y_train = pd.read_csv("y_train.csv", header=None, skiprows=0)
x_test = pd.read_csv("X_test.csv", header=None, skiprows=0)
y_test = pd.read_csv("y_test.csv", header=None, skiprows=0)

# 得到拟合模型，其中x_train,y_train为训练集
ENSTest = linear_model.ElasticNetCV(alphas=[0.0001, 0.0005, 0.001, 0.01, 0.1, 1, 10], l1_ratio=[.01, .1, .5, .9, .99],  max_iter=500).fit(x_train, y_train)

print("训练集准确度：", ENSTest.score(x_train, y_train))
print("测试集准确度：", ENSTest.score(x_test, y_test))
y_predict = ENSTest.predict(x_test)
print("MAE:", mean_absolute_error(y_test, y_predict))
