from xgboost import XGBRegressor
import pandas as pd

# x_train = pd.read_csv("pca_x_train.csv", header=None, skiprows=0)  # pca，未归一化（测试集准确度高于归一化后）
# y_train = pd.read_csv("y_train.csv", header=None, skiprows=0)
# x_test = pd.read_csv("pca_x_test.csv", header=None, skiprows=0)
# y_test = pd.read_csv("y_test.csv", header=None, skiprows=0)

x_train = pd.read_csv("X_train.csv", header=None, skiprows=0)  # pca，未归一化（测试集准确度高于归一化后）
y_train = pd.read_csv("y_train.csv", header=None, skiprows=0)
x_test = pd.read_csv("X_test.csv", header=None, skiprows=0)
y_test = pd.read_csv("y_test.csv", header=None, skiprows=0)


# x_train = pd.read_csv("normalized_pca_x_train.csv", header=None, skiprows=0)  # pca，归一化
# y_train = pd.read_csv("y_train.csv", header=None, skiprows=0)
# x_test = pd.read_csv("normalized_pca_x_test.csv", header=None, skiprows=0)
# y_test = pd.read_csv("y_test.csv", header=None, skiprows=0)


fit1 = XGBRegressor()

fit1.fit(x_train, y_train)

print('训练集准确度：', fit1.score(x_train, y_train))
print('测试集准确度：', fit1.score(x_test, y_test))
